#!/usr/bin/env node
"use strict";
// ─────────────────────────────────────────────────────────────────────────────
//  QR Code Generator para E-commerces — Terminal Edition
//  Sem dependências externas | Node.js puro
// ─────────────────────────────────────────────────────────────────────────────
const readline = require("readline");
const fs = require("fs");
const path = require("path");
const { generateMatrix } = require("./qr-engine.js");

// ── ANSI ─────────────────────────────────────────────────────────────────────
const C = {
  reset:   "\x1b[0m", bold:    "\x1b[1m", dim:     "\x1b[2m",
  black:   "\x1b[30m", red:     "\x1b[31m", green:   "\x1b[32m",
  yellow:  "\x1b[33m", blue:    "\x1b[34m", magenta: "\x1b[35m",
  cyan:    "\x1b[36m", white:   "\x1b[37m",
  bgBlack: "\x1b[40m", bgWhite: "\x1b[47m",
  bgCyan:  "\x1b[46m", bgBlue:  "\x1b[44m",
  orange:  "\x1b[38;5;214m", bgOrange: "\x1b[48;5;214m",
  bgDark:  "\x1b[48;5;235m", gray: "\x1b[38;5;245m",
  bgGreen: "\x1b[42m", bgRed: "\x1b[41m",
};

const fmt = {
  title:   (s) => `${C.bold}${C.orange}${s}${C.reset}`,
  section: (s) => `${C.bold}${C.white}${s}${C.reset}`,
  success: (s) => `${C.green}✔  ${s}${C.reset}`,
  error:   (s) => `${C.red}✖  ${s}${C.reset}`,
  warn:    (s) => `${C.yellow}⚠  ${s}${C.reset}`,
  info:    (s) => `${C.cyan}ℹ  ${s}${C.reset}`,
  badge:   (s) => `${C.bgOrange}${C.black}${C.bold} ${s} ${C.reset}`,
  tag:     (s) => `${C.bgDark}${C.gray} ${s} ${C.reset}`,
  key:     (s) => `${C.bold}${C.cyan}${s}${C.reset}`,
  label:   (s) => `${C.dim}${s}${C.reset}`,
  prompt:  ()  => `${C.orange}qr-gen${C.reset}${C.bold}>${C.reset} `,
};

const LINE  = `${C.dim}${"─".repeat(64)}${C.reset}`;
const DLINE = `${C.orange}${"═".repeat(64)}${C.reset}`;

// ── State ────────────────────────────────────────────────────────────────────
const SESSION = {
  history: [],   // { label, url, file, ecl, color, bg }
  outputDir: process.cwd(),
  defaultEcl: 1, // M
  defaultColor: "#000000",
  defaultBg: "#FFFFFF",
  defaultStyle: "square", // square | rounded | dots
};

const ECL_NAMES  = ["L (7%)",  "M (15%)", "Q (25%)", "H (30%)"];
const ECL_LABELS = ["Baixa",   "Média",   "Alta",    "Máxima"];
const STYLES     = ["square", "rounded", "dots"];
const STYLE_EMOJIS = { square: "◼", rounded: "⬛", dots: "⏺" };

// ── QR Renderers ─────────────────────────────────────────────────────────────

// Terminal render (block chars)
function renderTerminal(matrix, size) {
  const QR_BLOCK = "██";
  const EMPTY    = "  ";
  const lines = [];
  const border = C.bgWhite + EMPTY.repeat(size + 2) + C.reset;
  lines.push(border);
  for (let r = 0; r < size; r++) {
    let line = C.bgWhite + EMPTY;
    for (let c = 0; c < size; c++) {
      if (matrix[r][c] === 1) line += C.bgWhite + C.black + QR_BLOCK;
      else line += C.bgWhite + "  ";
    }
    line += EMPTY + C.reset;
    lines.push(line);
  }
  lines.push(border);
  return lines;
}

// SVG render
function renderSVG(matrix, size, opts = {}) {
  const {
    color = "#000000", bg = "#FFFFFF",
    style = "square", moduleSize = 10,
    label = "", url = "", logo = false,
  } = opts;

  const quiet = 4;
  const totalSize = (size + quiet * 2) * moduleSize;
  const r = style === "rounded" ? moduleSize * 0.3 : style === "dots" ? moduleSize * 0.45 : 0;

  let modules = "";
  for (let row = 0; row < size; row++) {
    for (let col = 0; col < size; col++) {
      if (matrix[row][col] !== 1) continue;
      const x = (col + quiet) * moduleSize;
      const y = (row + quiet) * moduleSize;
      if (style === "dots") {
        modules += `<circle cx="${x + moduleSize/2}" cy="${y + moduleSize/2}" r="${moduleSize * 0.42}" fill="${color}"/>`;
      } else {
        modules += `<rect x="${x}" y="${y}" width="${moduleSize}" height="${moduleSize}" rx="${r}" ry="${r}" fill="${color}"/>`;
      }
    }
  }

  // Corner finder patterns — always square for scan reliability
  function finderSVG(ox, oy) {
    const s = moduleSize;
    return `<rect x="${(ox+quiet)*s}" y="${(oy+quiet)*s}" width="${7*s}" height="${7*s}" rx="2" fill="${color}"/>` +
           `<rect x="${(ox+quiet+1)*s}" y="${(oy+quiet+1)*s}" width="${5*s}" height="${5*s}" rx="1" fill="${bg}"/>` +
           `<rect x="${(ox+quiet+2)*s}" y="${(oy+quiet+2)*s}" width="${3*s}" height="${3*s}" rx="0" fill="${color}"/>`;
  }

  const labelH = label ? 28 : 0;
  const totalH = totalSize + labelH;

  let labelSVG = "";
  if (label) {
    labelSVG = `<text x="${totalSize/2}" y="${totalSize + 20}" text-anchor="middle" font-family="'Segoe UI', Arial, sans-serif" font-size="13" fill="${color}" opacity="0.7">${escapeXML(label)}</text>`;
  }

  return `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="${totalSize}" height="${totalH}" viewBox="0 0 ${totalSize} ${totalH}">
  <title>QR Code${label ? ": " + label : ""}</title>
  <desc>QR Code gerado para: ${escapeXML(url || label)}</desc>
  <rect width="${totalSize}" height="${totalH}" fill="${bg}" rx="0"/>
  ${modules}
  ${labelSVG}
</svg>`;
}

// HTML render (standalone, scan-friendly)
function renderHTML(matrix, size, opts = {}) {
  const {
    color = "#000000", bg = "#FFFFFF",
    style = "square", moduleSize = 8,
    label = "", url = "", description = "",
    platform = "", price = "",
  } = opts;

  const svgContent = renderSVG(matrix, size, { color, bg, style, moduleSize, label, url });

  const platformBadge = platform ? `<span class="badge">${escapeHTML(platform)}</span>` : "";
  const priceTag = price ? `<div class="price">R$ ${escapeHTML(price)}</div>` : "";
  const descTag = description ? `<p class="desc">${escapeHTML(description)}</p>` : "";

  return `<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>QR Code — ${escapeHTML(label || url)}</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: 'Segoe UI', Arial, sans-serif; background: #f5f5f5; display: flex; align-items: center; justify-content: center; min-height: 100vh; padding: 2rem; }
  .card { background: #fff; border-radius: 16px; box-shadow: 0 4px 32px rgba(0,0,0,0.10); padding: 2rem 2.5rem; max-width: 420px; width: 100%; text-align: center; }
  .header { margin-bottom: 1.5rem; }
  .badge { display: inline-block; background: #FF5722; color: #fff; font-size: 11px; font-weight: 700; padding: 3px 10px; border-radius: 20px; letter-spacing: 0.5px; text-transform: uppercase; margin-bottom: 0.5rem; }
  h2 { font-size: 1.25rem; color: #1a1a1a; font-weight: 700; margin-bottom: 0.25rem; }
  .desc { font-size: 0.85rem; color: #666; margin-top: 0.4rem; }
  .price { font-size: 1.5rem; font-weight: 800; color: #e65100; margin-top: 0.5rem; }
  .qr-wrap { display: flex; justify-content: center; align-items: center; margin: 1.5rem 0; padding: 1rem; background: #fafafa; border-radius: 12px; border: 1.5px dashed #e0e0e0; }
  .qr-wrap svg { max-width: 100%; height: auto; }
  .url-box { background: #f0f0f0; border-radius: 8px; padding: 0.6rem 1rem; font-size: 0.75rem; color: #444; word-break: break-all; margin-bottom: 1rem; }
  .footer { font-size: 0.7rem; color: #aaa; margin-top: 1rem; }
  .scan-hint { font-size: 0.8rem; color: #888; display: flex; align-items: center; justify-content: center; gap: 6px; margin-bottom: 0.5rem; }
  .scan-hint::before { content: "📱"; }
  a { color: #FF5722; text-decoration: none; }
</style>
</head>
<body>
<div class="card">
  <div class="header">
    ${platformBadge}
    <h2>${escapeHTML(label || "Produto")}</h2>
    ${descTag}
    ${priceTag}
  </div>
  <div class="qr-wrap">${svgContent}</div>
  <p class="scan-hint">Aponte a câmera para escanear</p>
  <div class="url-box"><a href="${escapeHTML(url)}" target="_blank">${escapeHTML(url)}</a></div>
  <div class="footer">Gerado por QR-Gen E-commerce • ${new Date().toLocaleDateString("pt-BR")}</div>
</div>
</body>
</html>`;
}

// ── Helpers ──────────────────────────────────────────────────────────────────
function escapeXML(s) { return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;"); }
function escapeHTML(s) { return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;"); }

function slugify(s) {
  return s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 40) || "qrcode";
}

function sanitizeColor(s) {
  const trimmed = s.trim();
  if (/^#[0-9a-fA-F]{3,6}$/.test(trimmed)) return trimmed;
  const named = { preto:"#000000", branco:"#FFFFFF", azul:"#1565C0", verde:"#2E7D32", vermelho:"#C62828", laranja:"#E65100", roxo:"#6A1B9A", rosa:"#AD1457", cinza:"#546E7A" };
  return named[trimmed.toLowerCase()] || "#000000";
}

function validateURL(s) {
  try { new URL(s); return true; } catch { return s.length > 0; }
}

function saveFile(filePath, content, encoding = "utf8") {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  fs.writeFileSync(filePath, content, encoding);
}

// ── CLI UI ───────────────────────────────────────────────────────────────────
const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const ask = (q) => new Promise((res) => rl.question(q, res));

async function askWithDefault(prompt, def) {
  const raw = await ask(`  ${prompt} ${def ? C.dim + "[" + def + "]" + C.reset : ""}: `);
  return raw.trim() || def || "";
}

function printHeader() {
  console.clear();
  console.log("");
  console.log(DLINE);
  console.log(`${C.bgOrange}${C.black}${C.bold}${"  📱  QR CODE GENERATOR — E-COMMERCE EDITION".padEnd(64)}${C.reset}`);
  console.log(`${C.bgDark}${C.gray}${"  Node.js • Sem dependências • SVG + HTML + Terminal".padEnd(64)}${C.reset}`);
  console.log(DLINE);
}

function printMenu() {
  console.log(`
${fmt.section("MENU PRINCIPAL")}
${LINE}
  ${fmt.badge("1")} Gerar QR Code rápido      ${fmt.badge("2")} Gerar QR Code avançado
  ${fmt.badge("3")} Batch — múltiplos QRs     ${fmt.badge("4")} Histórico da sessão
  ${fmt.badge("5")} Configurações padrão       ${fmt.badge("6")} Demonstração (exemplos)
  ${fmt.badge("?")} Ajuda / Formatos           ${fmt.badge("q")} Sair
${LINE}`);
}

function printHelp() {
  console.log(`
${fmt.section("AJUDA — Formatos e Dicas")}
${LINE}
  ${fmt.key("URLs Suportadas:")}
    • Links de produtos:  https://loja.com/produto/123
    • Shopee / Mercado Livre / Amazon / qualquer e-commerce
    • WhatsApp:           https://wa.me/5511999999999
    • PIX:                https://nubank.com.br/cobrar/...
    • Qualquer texto ou URL até ~500 caracteres

  ${fmt.key("Níveis de Correção de Erro:")}
    • L (7%)   — menor QR, sem logo                    
    • M (15%)  — padrão recomendado                    
    • Q (25%)  — use se for imprimir pequeno           
    • H (30%)  — ideal para adicionar logo no centro   

  ${fmt.key("Estilos:")}
    • square   — quadrados clássicos (melhor leitura)
    • rounded  — cantos arredondados (visual moderno)
    • dots     — pontos circulares (mais estiloso)

  ${fmt.key("Cores (exemplos):")}
    • #000000  preto  azul  verde  vermelho  laranja  roxo
    • Qualquer cor hex: #1565C0

  ${fmt.key("Arquivos gerados:")}
    • .svg  — vetor, escalonável, ideal para impressão
    • .html — página completa com card do produto
${LINE}`);
}

function printHistory() {
  if (SESSION.history.length === 0) {
    console.log(fmt.warn("Nenhum QR gerado nesta sessão."));
    return;
  }
  console.log(`\n${fmt.section("📋 HISTÓRICO DA SESSÃO")} ${fmt.tag(SESSION.history.length + " gerados")}`);
  console.log(LINE);
  SESSION.history.forEach((h, i) => {
    console.log(`  ${fmt.badge(String(i+1).padStart(2,"0"))} ${C.bold}${h.label}${C.reset}`);
    console.log(`       ${C.dim}URL: ${h.url.slice(0,55)}${h.url.length>55?"...":""}${C.reset}`);
    console.log(`       ${fmt.tag("ECL " + ECL_NAMES[h.ecl])} ${fmt.tag(h.style)} ${fmt.tag("cor " + h.color)}`);
    if (h.files) h.files.forEach(f => console.log(`       ${C.green}✔ ${f}${C.reset}`));
    console.log("");
  });
}

function printConfig() {
  console.log(`\n${fmt.section("⚙️  CONFIGURAÇÕES PADRÃO")}`);
  console.log(LINE);
  console.log(`  ECL:    ${fmt.key(ECL_NAMES[SESSION.defaultEcl])} (${ECL_LABELS[SESSION.defaultEcl]})`);
  console.log(`  Cor:    ${fmt.key(SESSION.defaultColor)}`);
  console.log(`  Fundo:  ${fmt.key(SESSION.defaultBg)}`);
  console.log(`  Estilo: ${fmt.key(SESSION.defaultStyle)} ${STYLE_EMOJIS[SESSION.defaultStyle]}`);
  console.log(`  Pasta:  ${fmt.key(SESSION.outputDir)}`);
  console.log(LINE);
}

async function selectECL(def = SESSION.defaultEcl) {
  console.log(`\n  ${fmt.key("Nível de correção de erro:")}`);
  ECL_NAMES.forEach((name, i) => console.log(`    ${fmt.badge(String(i))} ${name} — ${ECL_LABELS[i]}`));
  const raw = await ask(`  Escolha [0-3, padrão: ${def}]: `);
  const n = parseInt(raw.trim());
  return (!isNaN(n) && n >= 0 && n <= 3) ? n : def;
}

async function selectStyle(def = SESSION.defaultStyle) {
  console.log(`\n  ${fmt.key("Estilo dos módulos:")}`);
  STYLES.forEach((s, i) => console.log(`    ${fmt.badge(String(i))} ${STYLE_EMOJIS[s]} ${s}`));
  const raw = await ask(`  Escolha [0-2, padrão: ${def}]: `);
  const n = parseInt(raw.trim());
  return STYLES[n] !== undefined ? STYLES[n] : def;
}

function generateAndSave(opts) {
  const { url, label, ecl, color, bg, style, description, platform, price } = opts;
  const { matrix, size, version } = generateMatrix(url, ecl);
  const slug = slugify(label || url);
  const ts = Date.now();
  const files = [];

  // SVG
  const svgPath = path.join(SESSION.outputDir, `qr-${slug}-${ts}.svg`);
  const svgContent = renderSVG(matrix, size, { color, bg, style, moduleSize: 12, label, url });
  saveFile(svgPath, svgContent);
  files.push(svgPath);

  // HTML
  const htmlPath = path.join(SESSION.outputDir, `qr-${slug}-${ts}.html`);
  const htmlContent = renderHTML(matrix, size, { color, bg, style, moduleSize: 8, label, url, description, platform, price });
  saveFile(htmlPath, htmlContent);
  files.push(htmlPath);

  return { matrix, size, version, files };
}

// ── Flows ─────────────────────────────────────────────────────────────────────

async function flowQuick() {
  console.log(`\n${fmt.section("⚡ GERAR QR CODE RÁPIDO")}`);
  console.log(LINE);

  const url = await askWithDefault("URL do produto", "");
  if (!url) { console.log(fmt.error("URL é obrigatória.")); return; }
  if (!validateURL(url)) { console.log(fmt.warn("URL pode estar incorreta, mas prosseguindo...")); }

  const label = await askWithDefault("Nome do produto (para o arquivo)", slugify(url));

  console.log(fmt.info("Gerando QR Code..."));

  try {
    const { matrix, size, version, files } = generateAndSave({
      url, label,
      ecl: SESSION.defaultEcl,
      color: SESSION.defaultColor,
      bg: SESSION.defaultBg,
      style: SESSION.defaultStyle,
      description: "", platform: "", price: "",
    });

    // Terminal preview
    console.log(`\n  ${fmt.key("Preview no terminal:")} ${fmt.tag("v" + version)} ${fmt.tag(size + "x" + size + " módulos")}\n`);
    const lines = renderTerminal(matrix, size);
    const indent = "    ";
    lines.forEach(l => console.log(indent + l));
    console.log("");

    console.log(fmt.success(`QR Code gerado — versão ${version}, ${size}×${size} módulos`));
    files.forEach(f => console.log(fmt.success(`Salvo: ${f}`)));

    SESSION.history.push({ label, url, ecl: SESSION.defaultEcl, color: SESSION.defaultColor, style: SESSION.defaultStyle, files });

  } catch (e) {
    console.log(fmt.error("Erro ao gerar QR: " + e.message));
  }
}

async function flowAdvanced() {
  console.log(`\n${fmt.section("🎨 GERAR QR CODE AVANÇADO")}`);
  console.log(LINE);

  const url = await askWithDefault("URL do produto", "");
  if (!url) { console.log(fmt.error("URL é obrigatória.")); return; }

  const label = await askWithDefault("Nome do produto", "Produto");
  const description = await askWithDefault("Descrição curta (opcional)", "");
  const platform = await askWithDefault("Plataforma (ex: Shopee, ML, Amazon — opcional)", "");
  const price = await askWithDefault("Preço (ex: 49,90 — opcional)", "");

  const ecl = await selectECL();
  const style = await selectStyle();

  const colorInput = await askWithDefault("Cor dos módulos (hex ou nome)", SESSION.defaultColor);
  const color = sanitizeColor(colorInput);

  const bgInput = await askWithDefault("Cor do fundo", SESSION.defaultBg);
  const bg = sanitizeColor(bgInput);

  console.log(`\n  ${fmt.key("Resumo:")} ${label} | ECL ${ECL_NAMES[ecl]} | ${style} | ${color} sobre ${bg}`);
  const confirm = await ask("  Gerar? (s/n): ");
  if (confirm.toLowerCase() !== "s") { console.log(fmt.info("Cancelado.")); return; }

  console.log(fmt.info("Gerando QR Code personalizado..."));

  try {
    const { matrix, size, version, files } = generateAndSave({ url, label, ecl, color, bg, style, description, platform, price });

    console.log(`\n  ${fmt.key("Preview:")} ${fmt.tag("v" + version)} ${fmt.tag(size + "×" + size)}\n`);
    const lines = renderTerminal(matrix, size);
    lines.forEach(l => console.log("    " + l));
    console.log("");

    console.log(fmt.success(`Versão QR ${version} | ${size}×${size} módulos | ECL ${ECL_NAMES[ecl]}`));
    files.forEach(f => console.log(fmt.success("Salvo: " + f)));

    SESSION.history.push({ label, url, ecl, color, style, files });

  } catch (e) {
    console.log(fmt.error("Erro: " + e.message));
  }
}

async function flowBatch() {
  console.log(`\n${fmt.section("📦 BATCH — MÚLTIPLOS QR CODES")}`);
  console.log(LINE);
  console.log(fmt.info("Digite os produtos no formato:  Nome | URL | Preço (opcional)"));
  console.log(fmt.info("Uma linha por produto. Digite 'fim' para encerrar.\n"));

  const entries = [];
  let i = 1;
  while (true) {
    const line = (await ask(`  Produto ${i}: `)).trim();
    if (line.toLowerCase() === "fim" || line === "") break;
    const parts = line.split("|").map(s => s.trim());
    if (parts.length < 2) { console.log(fmt.warn("Formato inválido. Use: Nome | URL")); continue; }
    entries.push({ label: parts[0], url: parts[1], price: parts[2] || "" });
    i++;
  }

  if (entries.length === 0) { console.log(fmt.warn("Nenhum produto informado.")); return; }

  const ecl = await selectECL();
  const style = await selectStyle();

  console.log(`\n${fmt.info(`Gerando ${entries.length} QR Code(s)...`)}\n`);

  let ok = 0, fail = 0;
  for (const entry of entries) {
    try {
      const { files } = generateAndSave({
        ...entry, ecl, style,
        color: SESSION.defaultColor, bg: SESSION.defaultBg,
        description: "", platform: "",
      });
      console.log(fmt.success(`${entry.label}`));
      files.forEach(f => console.log(`        ${C.dim}${f}${C.reset}`));
      SESSION.history.push({ ...entry, ecl, style, color: SESSION.defaultColor, files });
      ok++;
    } catch (e) {
      console.log(fmt.error(`${entry.label}: ${e.message}`));
      fail++;
    }
  }
  console.log(`\n  ${C.bold}Concluído:${C.reset} ${C.green}${ok} gerados${C.reset}${fail > 0 ? `, ${C.red}${fail} erros${C.reset}` : ""}`);
}

async function flowConfig() {
  printConfig();
  console.log(`\n  Editar configurações padrão:\n`);

  const eclRaw = await ask(`  Novo ECL padrão [0-3, atual: ${SESSION.defaultEcl}]: `);
  if (eclRaw.trim() !== "") { const n = parseInt(eclRaw); if (!isNaN(n) && n >= 0 && n <= 3) SESSION.defaultEcl = n; }

  const styleRaw = await ask(`  Novo estilo padrão [square/rounded/dots, atual: ${SESSION.defaultStyle}]: `);
  if (STYLES.includes(styleRaw.trim())) SESSION.defaultStyle = styleRaw.trim();

  const colorRaw = await ask(`  Nova cor padrão [atual: ${SESSION.defaultColor}]: `);
  if (colorRaw.trim()) SESSION.defaultColor = sanitizeColor(colorRaw.trim());

  const bgRaw = await ask(`  Nova cor de fundo padrão [atual: ${SESSION.defaultBg}]: `);
  if (bgRaw.trim()) SESSION.defaultBg = sanitizeColor(bgRaw.trim());

  const dirRaw = await ask(`  Pasta de saída [atual: ${SESSION.outputDir}]: `);
  if (dirRaw.trim()) SESSION.outputDir = dirRaw.trim();

  console.log(fmt.success("Configurações salvas para esta sessão."));
  printConfig();
}

async function flowDemo() {
  console.log(`\n${fmt.section("🎬 DEMONSTRAÇÃO — Gerando exemplos reais")}`);
  console.log(LINE);

  const demos = [
    { url: "https://shopee.com.br/produto/fone-bluetooth-123456", label: "Fone Bluetooth TWS", platform: "Shopee", price: "89,90", style: "rounded", color: "#EE4D2D", description: "Fone sem fio com cancelamento de ruído" },
    { url: "https://produto.mercadolivre.com.br/MLB-123456789-mochila-notebook", label: "Mochila Notebook 15.6", platform: "Mercado Livre", price: "129,00", style: "dots", color: "#2D3277", description: "Mochila slim com compartimento para notebook" },
    { url: "https://wa.me/5511999990001?text=Quero+comprar", label: "Contato WhatsApp", platform: "WhatsApp", price: "", style: "square", color: "#128C7E", description: "Fale conosco pelo WhatsApp" },
  ];

  for (const d of demos) {
    console.log(`\n  ${C.bold}${d.label}${C.reset} ${fmt.tag(d.platform)}`);
    try {
      const { version, size, files } = generateAndSave({ ...d, ecl: 1, bg: "#FFFFFF" });
      console.log(fmt.success(`v${version} | ${size}×${size} módulos | estilo: ${d.style}`));
      files.forEach(f => console.log(`    ${C.dim}${f}${C.reset}`));
    } catch (e) {
      console.log(fmt.error(e.message));
    }
  }
  console.log(`\n${fmt.success("Demonstração concluída! Abra os arquivos .html no navegador.")}`);
}

// ── Main Loop ────────────────────────────────────────────────────────────────
async function main() {
  printHeader();
  console.log(fmt.info("Gerador de QR Codes para E-commerce — 100% Node.js puro, sem dependências!"));
  console.log(fmt.info(`Arquivos serão salvos em: ${C.bold}${SESSION.outputDir}${C.reset}`));
  printMenu();

  while (true) {
    const cmd = (await ask(`\n${fmt.prompt()}`)).trim().toLowerCase();
    switch (cmd) {
      case "1": await flowQuick(); break;
      case "2": await flowAdvanced(); break;
      case "3": await flowBatch(); break;
      case "4": printHistory(); break;
      case "5": await flowConfig(); break;
      case "6": await flowDemo(); break;
      case "?": printHelp(); break;
      case "":  printMenu(); break;
      case "q": case "exit": case "sair":
        console.log(`\n${fmt.info("Até logo! 📱")}\n`);
        rl.close(); process.exit(0);
      default:
        console.log(fmt.warn(`Opção "${cmd}" não reconhecida. Digite Enter para o menu.`));
    }
  }
}

main().catch(e => { console.error(e); rl.close(); process.exit(1); });
